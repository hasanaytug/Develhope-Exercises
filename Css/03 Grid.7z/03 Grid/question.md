Look at the layout in the example.png and try to replicate it using CSS Grid properties.

**Suggestion**:
The grid that contains all numbers should have 4 columns. Assign this rule `grid-template-columns: repeat(4, 1fr)` to the div where you put the numbers.
