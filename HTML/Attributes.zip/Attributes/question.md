
Add to the start.html page:
* a disabled button.
* an input field with label, in the range of 0-100 and double step (the input type number should have the focus on the opening of the page)
* a checkbox with label (the checkbox should be already selected)
* an input date type.

