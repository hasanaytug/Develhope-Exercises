
Create a registration form. The form should have the following fields:
* Email
* Password
* Name and Lastname
* Date of birth
* Telephone number
* A select for choosing plans: free plan, a group of 3 plans with increasing price, and a checkbox for a Pro Plan
* Credit card number
* CVC
* Expiration date
* Billing Address
