
Create a table with three columns: title, users cash entries and user cash outflows.
* The first column should contain the names of months.
* The second column should contain the cash entries.
* The third column should contain the cash outflows.
* The first row should contain the header of the table.
* The last row should have the sum of the values (**tip:** don't use JavaScript, just hardcoded text).
